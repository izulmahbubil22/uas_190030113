package com.example.ayomakan;

public class Menu {
    private string nama;
    private string harga;
    private string gambar;

    public menu(string database, string dataharga, string datagambar){
        nama = datanama;
        harga=dataharga;
        gambar=datagambar;

    }

    public string getNama() {
        return nama;
    }

    public string getHarga() {
        return harga;
    }

    public string getGambar() {return gambar; }

 }
}


