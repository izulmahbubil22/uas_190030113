package com.example.ayomakan;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;

import recyclerview.adapter;

public class menuadapter extends adapter<menuadapter.menuviewholder>{
    private context context;
    private arraylist<menu> menumakanan;

    public menuadapter(context context,arraylist<menu>menumakanans){
        context=mcontext;
        menus=menulaptop;



    }
    @NonNull
    @Override
    public menuviewholder oncreateviewholder(@NonNull Viewgroup parent, int viewtype){
        view v = layoutInflater.from(context).inflate(R.layout.item_menu,parent, attachToRoot: false);

        return new menuviewholder(v);
    }

    @Override
    public void  oncreateviewholder(@NonNull menuviewholder holder, int position){
        menu listbaru= menus.get(position);
        string gambarbaru = listbaru.getGambar();
        string harga= listbaru.getHarga();
        string nama= listbaru.getNama();

        holder.tvnamadata.setText(nama);
        holder. tvhargadata.setText(harga);
        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);





    }

    @Override
    public int getitemcount() {
        return menus.size();
    }



    public class menuviewholder extends  recyclerview.viewholder

    public class menuviewholder extends  recyclerview.viewholder{
        public imageview imdata;
        public textview tvhargadata;
        public textview tvnamadata;

        public menuviewholder(@NonNull view itemview){
            imdata= itemview.findviewByid(R.id.img_menu);
            tvhargadata= itemview.findviewByid(R.id.tv_harga);
            tvnamadata= itemview.findviewByid(R.id.tv_nama);



            super(itemview);
        }
    }


}